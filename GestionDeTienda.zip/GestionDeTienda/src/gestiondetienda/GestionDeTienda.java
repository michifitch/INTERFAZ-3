/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestiondetienda;

/**
 *
 * @author deyve
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class GestionDeTienda {

    public static void main(String[] args) {
        new Application();
    }
}

class Categoria {

    private String nombre;

    public Categoria(String nombre) {
        this.nombre = nombre;
    }

    public String mostrarInfo() {
        return "Categoría: " + nombre;
    }
}

class Producto {

    private String nombre;
    private double precio;
    private Categoria categoria;

    public Producto(String nombre, double precio, Categoria categoria) {
        this.nombre = nombre;
        this.precio = precio;
        this.categoria = categoria;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public String mostrarInfo() {
        return "Producto: " + nombre + "\nPrecio: $" + String.format("%.2f", precio) + "\nCategoría: " + categoria.mostrarInfo();
    }
}

class Cliente {

    private String nombre;
    private String apellido;
    private String idCliente;

    public Cliente(String nombre, String apellido, String idCliente) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.idCliente = idCliente;
    }

    public String mostrarInfo() {
        return "Cliente: " + nombre + " " + apellido + " (ID: " + idCliente + ")";
    }
}

class ItemOrden {

    private Producto producto;
    private int cantidad;

    public ItemOrden(Producto producto, int cantidad) {
        this.producto = producto;
        this.cantidad = cantidad;
    }

    public double calcularSubtotal() {
        return producto.getPrecio() * cantidad;
    }
}

class Orden {

    private Cliente cliente;
    private ArrayList<ItemOrden> items;
    private double total;

    public Orden(Cliente cliente) {
        this.cliente = cliente;
        this.items = new ArrayList<>();
        this.total = 0.0;
    }

    public void agregarItem(ItemOrden item, int cantidad) {
        items.add(item);
        calcularTotal();
    }

    public void calcularTotal() {
        total = items.stream().mapToDouble(ItemOrden::calcularSubtotal).sum();
    }

    public double getTotal() {
        return total;
    }

    public Cliente getCliente() {
        return cliente;
    }
}

class Application extends JFrame {

    private ArrayList<Producto> productos;
    private ArrayList<Cliente> clientes;
    private ArrayList<Orden> ordenes;
    private ArrayList<Categoria> categorias;

    private JTextField entryNombreProducto;
    private JTextField entryPrecioProducto;
    private JTextField entryCategoriaProducto;
    private JTextField entryNombreCliente;
    private JTextField entryApellidoCliente;
    private JTextField entryIdCliente;
    private JTextField entryProductoOrden;
    private JTextField entryCantidadOrden;
    private JLabel labelInfoOrden;

    public Application() {
        setTitle("Gestión de Tienda");

        productos = new ArrayList<>();
        clientes = new ArrayList<>();
        ordenes = new ArrayList<>();
        categorias = new ArrayList<>();

        setLayout(new GridLayout(12, 2));

        add(new JLabel("Nombre del producto:"));
        entryNombreProducto = new JTextField();
        add(entryNombreProducto);

        add(new JLabel("Precio del producto:"));
        entryPrecioProducto = new JTextField();
        add(entryPrecioProducto);

        add(new JLabel("Categoría del producto:"));
        entryCategoriaProducto = new JTextField();
        add(entryCategoriaProducto);

        JButton btnRegistrarProducto = new JButton("Registrar Producto");
        btnRegistrarProducto.addActionListener(e -> registrarProducto());
        add(btnRegistrarProducto);

        add(new JLabel("Nombre del cliente:"));
        entryNombreCliente = new JTextField();
        add(entryNombreCliente);

        add(new JLabel("Apellido del cliente:"));
        entryApellidoCliente = new JTextField();
        add(entryApellidoCliente);

        add(new JLabel("ID del cliente:"));
        entryIdCliente = new JTextField();
        add(entryIdCliente);

        JButton btnRegistrarCliente = new JButton("Registrar Cliente");
        btnRegistrarCliente.addActionListener(e -> registrarCliente());
        add(btnRegistrarCliente);

        add(new JLabel("Producto de la orden:"));
        entryProductoOrden = new JTextField();
        add(entryProductoOrden);

        add(new JLabel("Cantidad del producto:"));
        entryCantidadOrden = new JTextField();
        add(entryCantidadOrden);

        JButton btnAgregarItem = new JButton("Agregar Producto a Orden");
        btnAgregarItem.addActionListener(e -> agregarProductoOrden());
        add(btnAgregarItem);

        labelInfoOrden = new JLabel();
        labelInfoOrden.setVerticalAlignment(SwingConstants.TOP);
        add(labelInfoOrden);

        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        // Configuración de la posición de la ventana
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(screenSize.width - getWidth() - 50, 50);
    }

    private void registrarProducto() {
        String nombre = entryNombreProducto.getText();
        double precio = Double.parseDouble(entryPrecioProducto.getText());
        String nombreCategoria = entryCategoriaProducto.getText();

        Categoria categoria = new Categoria(nombreCategoria);
        Producto producto = new Producto(nombre, precio, categoria);
        productos.add(producto);

        String info = producto.mostrarInfo();
        labelInfoOrden.setText("Producto registrado:\n" + info);
    }

    private void registrarCliente() {
        String nombre = entryNombreCliente.getText();
        String apellido = entryApellidoCliente.getText();
        String idCliente = entryIdCliente.getText();

        Cliente cliente = new Cliente(nombre, apellido, idCliente);
        clientes.add(cliente);

        String info = cliente.mostrarInfo();
        labelInfoOrden.setText("Cliente registrado:\n" + info);
    }

    private void agregarProductoOrden() {
        String nombreProducto = entryProductoOrden.getText();
        int cantidad = Integer.parseInt(entryCantidadOrden.getText());

        Producto productoEncontrado = null;
        for (Producto producto : productos) {
            if (producto.getNombre().equals(nombreProducto)) {
                productoEncontrado = producto;
                break;
            }
        }

        if (productoEncontrado != null) {
            ItemOrden itemOrden = new ItemOrden(productoEncontrado, cantidad);
            boolean ordenExistente = false;

            for (Orden orden : ordenes) {
                if (orden.getCliente().equals(clientes.get(clientes.size() - 1))) {
                    orden.agregarItem(itemOrden, cantidad);
                    ordenExistente = true;
                    break;
                }
            }

            if (!ordenExistente) {
                Orden nuevaOrden = new Orden(clientes.get(clientes.size() - 1));
                nuevaOrden.agregarItem(itemOrden, cantidad);
                ordenes.add(nuevaOrden);
                nuevaOrden.calcularTotal();

                String info = "Se agregó " + cantidad + " " + productoEncontrado.getNombre() + "(s) a la orden.\nTotal de la orden para "
                        + nuevaOrden.getCliente().mostrarInfo() + ": $" + String.format("%.2f", nuevaOrden.getTotal());
                labelInfoOrden.setText(info);

                JOptionPane.showMessageDialog(this, "Producto agregado a la orden correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            labelInfoOrden.setText("Producto no encontrado.");
        }
    }

}
